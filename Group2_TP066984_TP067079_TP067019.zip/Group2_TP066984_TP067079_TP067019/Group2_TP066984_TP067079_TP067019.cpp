// Group2_TP066984_TP067079_TP067019.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Rent System for Assignment - GROUP 2

// *********************************************************************************************************************
// ****************************************************IMPORT LIBRARY***************************************************
// *********************************************************************************************************************
#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <string>
#include <typeinfo>
#include <vector>
#include <limits>
#include <list>
using namespace std;

// *********************************************************************************************************************
// *************************************************FUNCTION DECLARATION************************************************
// *********************************************************************************************************************
inline void displayProgressBar();
inline bool verifyTenant(string un);
inline int getNextID();
inline void registerTenant();
inline void tenantMainMenu();
inline void userPrompt();
inline void returnToMainMenu();
inline void addNewManager();
inline void ModifyManagerStatus();
inline void FilterTenants();
inline void FilterPropertyMenu();
inline void AdminLogOut();
inline void AdminMainMenu();
inline void managerMainMenu();

// *********************************************************************************************************************
// **********************************************TIME VISUALISATION*****************************************************
// *********************************************************************************************************************
// Display loading dotted bar
inline void displayProgressBar() {
	cout << endl << endl << "-----------------------------------------------LOADING-----------------------------------------------" << endl;
	for (int i = 0; i <= 100; i++) {
		if (i == 0 || i == 100) {
			cout << "+";
		}
		else {
			cout << "*";
		}
		// Ensure output is displayed immediately
		cout.flush();
		this_thread::sleep_for(chrono::milliseconds(10));
	}
}

// *********************************************************************************************************************
// ***************************************************VIRTUAL CLASS*****************************************************
// *********************************************************************************************************************
class User {
public:
	virtual string getUsername() = 0;
	virtual string getPassword() = 0;
};

// *********************************************************************************************************************
// *****************************************************MAIN CLASS******************************************************
// *********************************************************************************************************************
// Tenant class
class Tenant : public User {
private:
	long id;
	string username, password;
	bool status;
public:
	Tenant(string username, string password) {
		this->id = 0;
		this->username = username;
		this->password = password;
		this->status = true;
	}

	Tenant(long id, string username, string password, bool status) {
		this->id = id;
		this->username = username;
		this->password = password;
		this->status = status;
	}

	// Destructor to remove a tenant object
	~Tenant() {}

	// Operator overloading for comparing two tenant objects
	bool operator==(const Tenant& other) const {
		return this->username == other.username && this->password == other.password;
	}

	// Getter and setter of data
	long getId() const {
		return this->id;
	}
	string getUsername() override {
		return this->username;
	}
	string getPassword() override {
		return this->password;
	}
	bool getStatus() const {
		return this->status;
	}
	void setStatus(bool status) {
		this->status = status;
	}
};

// Manager class
class Manager : public User {
private:
	long id;
	string username, password;
	bool status;
public:
	// Constructors to create new manager object
	//Manager() {}

	Manager(string username, string password) {
		this->id = 0;
		this->username = username;
		this->password = password;
		this->status = true;
	}

	Manager(long id, string username, string password, bool status) {
		this->id = id;
		this->username = username;
		this->password = password;
		this->status = status;
	}

	// Destructor to remove a tenant object
	~Manager() {}

	// Operator overloading for comparing two tenant objects
	bool operator==(const Manager& other) const {
		return this->username == other.username && this->password == other.password;
	}

	// Getter and setter of data
	long getId() const {
		return this->id;
	}
	string getUsername() override {
		return this->username;
	}
	string getPassword() override {
		return this->password;
	}
	bool getStatus() const {
		return this->status;
	}
	void setStatus(bool status) {
		this->status = status;
	}
};

// Admin class
class Admin : public User {
private:
	long id;
	string username, password;
	bool status;
public:
	// Constructors to create new manager object
	//Admin() {}

	Admin(string username, string password) {
		this->id = 0;
		this->username = username;
		this->password = password;
		this->status = true;
	}

	Admin(long id, string username, string password, bool status) {
		this->id = id;
		this->username = username;
		this->password = password;
		this->status = status;
	}

	// Destructor to remove a tenant object
	~Admin() {}

	// Operator overloading for comparing two tenant objects
	bool operator==(const Admin& other) const {
		return this->username == other.username && this->password == other.password;
	}

	// Getter and setter of data
	long getId() const {
		return this->id;
	}
	string getUsername() override {
		return this->username;
	}
	string getPassword() override {
		return this->password;
	}
	bool getStatus() const {
		return this->status;
	}
	void setStatus(bool status) {
		this->status = status;
	}
};

// *********************************************************************************************************************
// ***************************************************REGISTER TENANT***************************************************
// *********************************************************************************************************************
// Check whether tenant has registered the account before 
inline bool verifyTenant(string un) {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");

	// Check whether file exist or not
	if (!file.is_open()) {
		cout << endl << "File not exist! Creating a new file..." << endl;
		ofstream newFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
		return false;
	}
	else {
		cout << endl << "File exist! Verifying account... " << endl;
	}

	string line, id, username, password, status, empty;

	// Check is there empty lines at the end of the file and remove it before data processing
	while (!file.eof()) {
		getline(file, id) && getline(file, username) && getline(file, password) && getline(file, status) && getline(file, empty);

		// Remove the carriage return characters from each of the line from the file
		id.erase(id.find_last_not_of("\r") + 1);
		username.erase(username.find_last_not_of("\r") + 1);
		password.erase(id.find_last_not_of("\r") + 1);
		status.erase(status.find_last_not_of("\r") + 1);
		empty.erase(empty.find_last_not_of("\r") + 1);

		// System check whether username exists or not
		if (username == un) {
			cout << "Account already registered! Please login to your account!" << endl;
			return true;	// USER EXIST
		}
		else {
			continue;
		}
	}
	file.close();
	return false;
}

// Generate increment ID for the tenant 
inline int getNextID() {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");

	// Check whether file exist or not
	if (!file.is_open()) {
		cout << endl << "File not exist!" << endl;
		return -1;
	}

	string readLine;
	int tenantEntry = 1;
	int numberOfLine = 0;
	const int LINES_PER_TENANT = 5;
	const int FIRST_INDEX_LINE = 1;

	// Start read the file line by line
	while (getline(file, readLine)) {
		// Increment of line read by 1 after one line done
		numberOfLine++;

		// Skip any empty line and line that are non-start line of a new user
		if (readLine.empty() || numberOfLine % LINES_PER_TENANT != FIRST_INDEX_LINE) {
			continue;
		}

		// Increment of tenant entry by 1 after the condition satisfied (5 text lines per tenant)
		tenantEntry++;
	}
	file.close();
	return tenantEntry++;	//Increment of ID by 1
}

// Register tenant if the account does not exist
inline void registerTenant() {
	string usernameInput, passwordInput;
	string tenantStatus = "Active";

	// 1. Open text file for read, write, and append back into the text file
	ofstream file("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt", ios::in | ios::out | ios::app);
	// Tenant* found = nullptr;
	if (!file) {
		cout << endl << "File not exist!" << endl;
		return;
	}

	// 2. Obtain username input from user
	cout << "*****************************************************************************" << endl;
	cout << "************************* TENANT REGISTER PAGE ******************************" << endl;
	cout << "*****************************************************************************" << endl << endl;

	// Clear any remaining input in cin buffer
	cin.ignore(numeric_limits<streamsize>::max(), '\n');

	do {
		cout << "Please enter your username (Format: Minimum 4 characters & start with 'T'): ";
		cin >> usernameInput;

		// 3. Check whether the input username starts with 'T'
		if (usernameInput[0] != 'T') {
			cout << "Registration failed! Please register your new username starts with 'T'! Please try again!" << endl << endl;
			continue;
		}
		else if (usernameInput.length() < 4) {
			cout << "Registration failed! Please make sure your new username more than 4 characters! Please try again!" << endl << endl;
			continue;
		}

		// 4. Compare username input with existing username in the file, return true if user exist
		bool accountExist = verifyTenant(usernameInput);
		if (accountExist) {
			break;
		}

		// 5. Obtain password input from user
		cout << "Please enter your password: ";
		cin >> passwordInput;

		// 6. Write tenant information into tenant.txt file
		file << getNextID() << endl << usernameInput << endl << passwordInput << endl << tenantStatus << endl << endl;
		file.close();
		return;
	} while (usernameInput[0] != 'T' || usernameInput.length() < 4);
}

// *********************************************************************************************************************
// ***************************************************LOGIN FUNCTION****************************************************
// *********************************************************************************************************************
// Find tenant account inside the text file
inline Tenant* searchTenant(Tenant tenant) {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	Tenant* found = nullptr;
	string id, username, password, status, emptySpace;

	// Check whether file exist or not
	if (!file.is_open()) {
		cout << endl << "File not exist!" << endl;
		return nullptr;
	}

	while (!file.eof()) {
		getline(file, id);
		getline(file, username);
		getline(file, password);
		getline(file, status);
		getline(file, emptySpace);

		// Remove the carriage return characters from each of the line from the file
		id.erase(id.find_last_not_of("\r") + 1);
		username.erase(username.find_last_not_of("\r") + 1);
		password.erase(password.find_last_not_of("\r") + 1);
		status.erase(status.find_last_not_of("\r") + 1);
		emptySpace.erase(emptySpace.find_last_not_of("\r") + 1);

		// System check whether tenant account exist or not
		if (username == tenant.getUsername() && password == tenant.getPassword()) {
			bool statusMatch;
			if (status == "Active") {
				statusMatch = true;
			}
			else {
				statusMatch = false;
			}

			// Input the tenant list information into the tenant object
			found = new Tenant(stol(id), username, password, statusMatch);
			break;
		}
	}
	file.close();
	return found;
}

// Find manager account inside the text file
inline Manager* searchManager(Manager manager) {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\manager.txt");
	Manager* found = nullptr;
	string id, username, password, status, emptySpace;

	// Check whether file exist or not
	if (!file.is_open()) {
		cout << endl << "File not exist!" << endl;
		return nullptr;
	}

	while (!file.eof()) {
		getline(file, id);
		getline(file, username);
		getline(file, password);
		getline(file, status);
		getline(file, emptySpace);

		// Remove the carriage return characters from each of the line from the file
		id.erase(id.find_last_not_of("\r") + 1);
		username.erase(username.find_last_not_of("\r") + 1);
		password.erase(password.find_last_not_of("\r") + 1);
		status.erase(status.find_last_not_of("\r") + 1);
		emptySpace.erase(emptySpace.find_last_not_of("\r") + 1);

		// System check whether manager account exist or not
		if (username == manager.getUsername() && password == manager.getPassword()) {
			bool statusMatch;
			if (status == "Active") {
				statusMatch = true;
			}
			else {
				statusMatch = false;
			}

			// Input the tenant list information into the tenant object
			found = new Manager(stol(id), username, password, statusMatch);
			break;
		}
	}
	file.close();
	return found;
}

// Find admin account inside the text file
inline Admin* searchAdmin(Admin admin) {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\admin.txt");
	Admin* found = nullptr;
	string id, username, password, status, emptySpace;

	// Check whether file exist or not
	if (!file.is_open()) {
		cout << endl << "File not exist!" << endl;
		return nullptr;
	}

	while (!file.eof()) {
		getline(file, id);
		getline(file, username);
		getline(file, password);
		getline(file, status);
		getline(file, emptySpace);

		// Remove the carriage return characters from each of the line from the file
		id.erase(id.find_last_not_of("\r") + 1);
		username.erase(username.find_last_not_of("\r") + 1);
		password.erase(password.find_last_not_of("\r") + 1);
		status.erase(status.find_last_not_of("\r") + 1);
		emptySpace.erase(emptySpace.find_last_not_of("\r") + 1);

		// System check whether admin account exist or not
		if (username == admin.getUsername() && password == admin.getPassword()) {
			bool statusMatch;
			if (status == "Active") {
				statusMatch = true;
			}
			else {
				statusMatch = false;
			}

			// Input the tenant list information into the tenant object
			found = new Admin(stol(id), username, password, statusMatch);
			break;
		}
	}
	file.close();
	return found;
}

// Login part for all users
inline User* login() {
	string username, password;
	User* user = nullptr;

	// Clear any remaining input in cin buffer
	cin.ignore(numeric_limits<streamsize>::max(), '\n');

	// Verify user login by enabling user input
	while (user == nullptr) {
		cout << "*****************************************************************************" << endl;
		cout << "****************************** USER LOGIN PAGE ******************************" << endl;
		cout << "*****************************************************************************" << endl << endl;
		cout << "Please enter your username: ";
		getline(cin, username);
		cout << "Please enter your password: ";
		getline(cin, password);

		// If username starts with 'T', 'M', 'A'
		if (username[0] == 'T') {
			Tenant* tenant = new Tenant(username, password);
			user = searchTenant(*tenant);
		}
		else if (username[0] == 'M') {
			Manager* manager = new Manager(username, password);
			user = searchManager(*manager);
		}
		else if (username[0] == 'A') {
			Admin* admin = new Admin(username, password);
			user = searchAdmin(*admin);
		}

		// Display user not found if user not exist
		if (user == nullptr) {
			cout << "User not found!" << endl << endl;
		}
	}
	return user;
}

string& getCurrentUsername() {
	static string currentUsername;
	return currentUsername;
}

// First execution code when program start - DETERMINE USER ROLE
inline void userPrompt() {
	char choice;	// Store user choice for tenant role selection
	cout << "***********************************************************************************" << endl;
	cout << "********  WELCOME TO ASIA PACIFIC HOME (APH) FOR KLANG VALLEY, MALAYSIA!!  ********" << endl;
	cout << "***********************************************************************************" << endl << endl;
	while (true) {
		cout << "Are you a tenant? (Y for YES, N for NO, E for EXIT): ";
		cin >> choice;
		if (choice == 'y' || choice == 'Y') {
			system("cls");
			registerTenant();	// Proceed to Register Tenant page
			// Perform again user login
			system("cls");
			cout << "Looks like you have registered an account! Please login your account!" << endl << endl;
			User* user = login();
			if (user != nullptr) {
				// IMPORTANT!!!
				// ********************************************************************************
				// *Check user's role using typeid and perform specific operations once user input*
				// ********************************************************************************
				if (typeid(*user) == typeid(Tenant)) {
					getCurrentUsername() = user->getUsername();
					string username = user->getUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					tenantMainMenu();	// Tenant Main Menu
				}
				else if (typeid(*user) == typeid(Manager)) {
					string username = user->getUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					managerMainMenu();	// Manager Main Menu
				}
				else if (typeid(*user) == typeid(Admin)) {
					string username = user->getUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					AdminMainMenu();	// Admin Main Menu
				}
			}
			return;
		}
		else if (choice == 'n' || choice == 'N') {
			system("cls");
			User* user = login();
			if (user != nullptr) {
				// IMPORTANT!!!
				// ********************************************************************************
				// *Check user's role using typeid and perform specific operations once user input*
				// ********************************************************************************
				if (typeid(*user) == typeid(Tenant)) {
					getCurrentUsername() = user->getUsername();
					string username = getCurrentUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					tenantMainMenu();	// Tenant Main Menu
				}
				else if (typeid(*user) == typeid(Manager)) {
					string username = user->getUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					managerMainMenu();	// Manager Main Menu
				}
				else if (typeid(*user) == typeid(Admin)) {
					string username = user->getUsername();
					cout << "WELCOME " << username << "!";
					displayProgressBar();
					AdminMainMenu();	// Admin Main Menu
				}
			}
			return;
		}
		else if (choice == 'e' || choice == 'E') {
			return;
			break;
		}
		else {
			cout << "Invalid input! Please try again!" << endl;
			cin.clear();	// Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
		}
	}
}

// *********************************************************************************************************************
// **************************************DATA STRUCTURES (LINKED LIST, QUEUE, SET)**************************************
// *********************************************************************************************************************
// Node class (for linked list)
template <typename T>
class Node {
private:
	T data;
public:
	Node<T>* next;
	// Constructors
	Node() {
		this->data = T();
		this->next = nullptr;
	}
	Node(T data, Node<T>* next = nullptr) {
		this->data = data;
		this->next = next;
	}
	T getData() {
		return data;
	}
	void setData(T data) {
		this->data = data;
	}
	void setNext(Node<T>* next) {
		this->next = next;
	}
	// Destructor
	~Node() {}
};

// LIST class
template <typename T>
class List {
private:
	Node<T>* head = nullptr;
	Node<T>* tail = nullptr;

	// Set the head of the list
	void setHead(Node<T>* head) {
		this->head = head;
	}

	// Function to get the tail of a linked list by providing head only
	Node<T>* getLastNode(Node<T>* head) {
		while (head && head->next) {
			head = head->next;
		}
		return head;
	}

	// Recursive QuickSort function for linked lists
	void quickSortRecur(Node<T>* low, Node<T>* high, const string& order, const string& attribute) {
		if (low == nullptr || high == nullptr || low == high)return;
		if (low != high && low != high->next) {
			Node<T>* pi = partition(low, high, order, attribute);
			if (pi != nullptr) {
				quickSortRecur(low, getPreviousNode(pi), order, attribute);
				quickSortRecur(pi->next, high, order, attribute);
			}
		}
	}

	void quickSortMultiRecur(Node<T>* low, Node<T>* high, const string& order) {
		if (low == nullptr || high == nullptr || low == high)return;
		if (low != high && low != high->next) {
			Node<T>* pi = multiAttPartition(low, high, order);
			if (pi != nullptr) {
				quickSortMultiRecur(low, getPreviousNode(pi), order);
				quickSortMultiRecur(pi->next, high, order);
			}
		}
	}

	Node<T>* getPreviousNode(Node<T>* referenceNode) {
		Node<T>* current = this->head;
		if (referenceNode == this->head || referenceNode == nullptr) {
			return nullptr;
		}
		while (current != nullptr && current->next != referenceNode) {
			current = current->next;
		}
		return current;
	}

	template <typename T>
	void swapNodeData(Node<T>* a, Node<T>* b) {
		T temp = a->getData();
		a->setData(b->getData());
		b->setData(temp);
	}

	// Function to perform partition process in quicksort.
	Node<T>* partition(Node<T>* low, Node<T>* high, const string& order, const string& attribute) {
		T pivot = high->getData();
		Node<T>* i = getPreviousNode(low);
		for (Node<T>* j = low; j != high; j = j->next) {
			bool condition = false;
			if (attribute == "rent") {
				condition = (order == "descending") ? (j->getData().getRent() > pivot.getRent()) : (j->getData().getRent() < pivot.getRent());
			}
			else if (attribute == "location") {
				condition = (order == "descending") ? (j->getData().getLocation() > pivot.getLocation()) : (j->getData().getLocation() < pivot.getLocation());
			}
			else if (attribute == "size") {
				condition = (order == "descending") ? (j->getData().getSize() > pivot.getSize()) : (j->getData().getSize() < pivot.getSize());
			}
			else if (attribute == "id") {
				condition = (order == "descending") ? (j->getData().getID() > pivot.getID()) : (j->getData().getID() < pivot.getID());
			}
			if (condition) {
				i = (i == nullptr) ? low : i->next;
				swapNodeData(i, j);
			}

		}
		i = (i == nullptr) ? low : i->next;
		swapNodeData(i, high);
		return i;
	}

	// Function to perform multi-attributes partition process in quicksort. (Monthly rent -> Location -> Size)
	Node<T>* multiAttPartition(Node<T>* low, Node<T>* high, const string& order) {
		T pivot = high->getData();
		Node<T>* i = getPreviousNode(low);
		for (Node<T>* j = low; j != high; j = j->next) {
			bool condition = false;
			if (j->getData().getRent() != pivot.getRent()) {
				condition = (order == "descending") ? (j->getData().getRent() > pivot.getRent()) : (j->getData().getRent() < pivot.getRent());
			}
			else if (j->getData().getLocation() != pivot.getLocation()) {
				condition = (order == "descending") ? (j->getData().getLocation() > pivot.getLocation()) : (j->getData().getLocation() < pivot.getLocation());
			}
			else {
				condition = (order == "descending") ? (j->getData().getSize() > pivot.getSize()) : (j->getData().getSize() < pivot.getSize());
			}
			if (condition) {
				i = (i == nullptr) ? low : i->next;
				swapNodeData(i, j);
			}

		}
		i = (i == nullptr) ? low : i->next;
		swapNodeData(i, high);
		return i;
	}

	Node<T>* obtainMiddleNode(Node<T>* left, Node<T>* right) {
		if (left == nullptr) {
			return nullptr;
		}

		Node<T>* first = left;
		Node<T>* second = left->next;

		while (second != right) {
			second = second->next;
			if (second != right) {
				first = first->next;
				second = second->next;
			}
		}
		return first;
	}

	int m_size = 0;
public:
	// Constructors
	List() {
		head = nullptr;
		tail = nullptr;
	}

	// Destructor
	~List() {
		Node<T>* temp = head;
		while (temp != nullptr) {
			Node<T>* nextNode = temp->next;
			// Delete the node once detect the next node
			temp = nextNode;
		}
		head = nullptr;
		tail = nullptr;
	}

	// Get first node
	Node<T>* getHead() {
		return head;
	}

	// Get last node
	Node<T>* getTail() {
		return tail;
	}

	Node<T>*& getHeadReference() {
		return head;
	}

	// Insert new node at the front of the linked list
	void pushFront(T data) {
		// Allocate a new node with the given data.
		Node<T>* newNode = new Node<T>(data);

		// If the list is currently empty, this new node becomes both the head and the tail.
		if (head == nullptr) {
			tail = newNode;
		}

		newNode->setNext(head);
		head = newNode;
	}

	// Insert new node at the index of the linked list
	void insertAtIndex(T data, int index) {
		if (index <= 0) {
			pushFront(data);
		}
		else {
			Node<T>* newNode = new Node<T>(data);
			Node<T>* temp = head;
			// Set the index to default (used to determine the index that user want to find)
			int findIndex = 0;

			while (temp != nullptr && findIndex < index - 1) {
				temp = temp->next;
				findIndex++;
			}

			if (temp == nullptr) {
				pushBack(data);
			}

			newNode->next = temp->next;
			temp->next = newNode;
		}
	}

	// Insert new node at the end of the linked list
	void pushBack(T data) {
		Node<T>* newNode = new Node<T>(data);
		if (head == nullptr) {
			head = newNode;
		}
		else {
			tail->next = newNode;
		}
		tail = newNode;
	}

	// Delete a node from the linked list
	bool remove(T data) {
		Node<T>* temp = head;
		if (temp->getData() == data) {
			head = temp->next;
			return true;
		}

		if (tail->getData() == data) {
			Node<T>* currentNode = head;
			while (currentNode->next->next != nullptr) {
				currentNode = currentNode->next;
			}
			Node<T>* del = currentNode->next;
			currentNode->next = nullptr;
			tail = currentNode;
			delete del;
			return true;
		}

		while (temp->next != nullptr && !(temp->next->getData() == data)) {
			temp = temp->next;
		}

		if (temp->next == nullptr && !(temp->getData() == data)) {
			throw out_of_range("Error! Data not exist!");
			return false;
		}

		Node<T>* del = temp->next;
		temp->next = temp->next->next;
		delete del;
		return true;
	}

	// Find the size of linked list - NUMBER OF NODES CONTAINED
	long size() {
		Node<T>* temp = head;
		long count = 0;
		while (temp != nullptr) {
			count++;
			temp = temp->next;
		}
		return count;
	}

	// List and display specific nodes in the linked list
	void display(const int num) {
		Node<T>* temp = head;
		int count = 0;
		char con = 'y';
		do {
			while (count < num) {
				temp->getData().display();
				temp = temp->next;
				count++;
				if (temp == nullptr) {
					cout << "\n" << string(150, '=') << endl;
					cout << endl << endl << "\t\tEnd of the list!" << endl;
					cout << "\n" << string(150, '=') << endl << endl;
					return;

				}
			}
			cout << "Enter 'Y' to continue or 'N' to stop the loop: ";
			cin >> con;
			count = 0;
			temp = temp->next;
			if (con == 'n' || con == 'N') {
				cout << "The loop stopped!" << endl;
				displayProgressBar();
				tenantMainMenu();
			}
		} while (con == 'y' || con == 'Y');
	}

	// List and display all the nodes in the linked list
	void displayAll() {
		int count = 0;
		Node<T>* temp = head;
		if (temp == nullptr) {
			cout << endl;
		}
		while (temp != nullptr) {
			cout << ++count << ". ";
			temp->getData().display();
			temp = temp->next;
		}
	}

	// -----------------------------------------------------------------------------------------------
	// |Sort the linked list based on arrangement given and return sorted linked list using QUICKSORT|
	// -----------------------------------------------------------------------------------------------
	void recomputeSize() {
		int count = 0;
		Node<T>* current = head;
		while (current != nullptr) {
			count++;
			current = current->next;
		}
		this->m_size = count;
	}

	void quickSort(const string& order, const string& attribute) {
		quickSortRecur(this->head, this->tail, order, attribute);
		this->recomputeSize();
	}

	void MultiAttQuickSort(const string& order) {
		quickSortMultiRecur(this->head, this->tail, order);
		this->recomputeSize();
	}

	// -----------------------------------------------------------------------------------------------
	// |Sort the linked list based on arrangement given and return sorted linked list using MERGESORT|
	// -----------------------------------------------------------------------------------------------
	// Utility function to split the linked list into two halves and return the middle node
	template<typename T>
	Node<T>* split(Node<T>* head) {
		Node<T>* slow = head;
		Node<T>* fast = head->next;
		while (fast && fast->next) {
			slow = slow->next;
			fast = fast->next->next;
		}
		return slow;
	}

	// Main MergeSort function for linked lists
	template<typename T>
	Node<T>* mergeSortAlgo(Node<T>* first, Node<T>* second, const string& order) {
		// Base cases
		if (!first) return second;
		if (!second) return first;

		Node<T>* mergedHead = nullptr;
		Node<T>* current = nullptr;

		while (first && second) {
			bool condition = false;
			// Compare based on Monthly Rent
			if (first->getData().getRent() != second->getData().getRent()) {
				condition = (order == "descending") ? (first->getData().getRent() > second->getData().getRent())
					: (first->getData().getRent() < second->getData().getRent());
			}
			// Compare based on Location if Monthly Rent is the same
			else if (first->getData().getLocation() != second->getData().getLocation()) {
				condition = (order == "descending") ? (first->getData().getLocation() > second->getData().getLocation())
					: (first->getData().getLocation() < second->getData().getLocation());
			}
			// Compare based on Size if Monthly Rent and Location are the same
			else {
				condition = (order == "descending") ? (first->getData().getSize() > second->getData().getSize())
					: (first->getData().getSize() < second->getData().getSize());
			}
			//Determine which node to pick next
			Node<T>* nextNode = nullptr;
			if (condition) {
				nextNode = first;
				first = first->next;
			}
			else {
				nextNode = second;
				second = second->next;
			}

			// If it's the first node in merged list
			if (!mergedHead) {
				mergedHead = nextNode;
				current = mergedHead;
			}
			else {
				current->next = nextNode;
				current = current->next;
			}
		}

		// One of the lists can still have elements, append it to the result
		if (first) {
			current->next = first;
		}
		else if (second) {
			current->next = second;
		}

		return mergedHead;
	}

	template<typename T>
	void mergeSort(Node<T>*& head, const string& order) {
		if (!head || !head->next) return;  // Base case
		// Split the list into two halves
		Node<T>* middle = split(head);
		Node<T>* secondHalf = middle->next;
		middle->next = nullptr;  // Terminate the first half of the list
		// Recursively sort both halves
		mergeSort(head, order);
		mergeSort(secondHalf, order);
		// Merge the sorted halves using mergeSortAlgo function
		head = mergeSortAlgo(head, secondHalf, order);
	}

	// ---------------------------------------------------------------------------------------------
	// |Filter and obtain the returned linked list that fulfill requirements by using LINEARSEARCH!|
	// ---------------------------------------------------------------------------------------------
	List<T> linearSearch(T value, string attribute) {
		List<T> result;
		Node<T>* temp = head;
		int count = 0;
		while (temp != nullptr && count < 1) {
			bool compare = false;
			if (attribute == "rent") {
				compare = temp->getData().getRent() == value.getRent();
			}
			else if (attribute == "location") {
				compare = temp->getData().getLocation() == value.getLocation();
			}
			else if (attribute == "size") {
				compare = temp->getData().getSize() == value.getSize();
			}
			else if (attribute == "id") {
				compare = temp->getData().getID() == value.getID();
			}

			if (compare) {
				result.pushBack(temp->getData());
				break;
			}

			temp = temp->next;
		}
		return result;
	}

	// ---------------------------------------------------------------------------------------------
	// |Filter and obtain the returned linked list that fulfill requirements by using BINARYSEARCH!|
	// ---------------------------------------------------------------------------------------------
	// Search a node in the linked list by using binary search for property
	List<T> binarySearch(T value, string attribute) {
		List<T> result;
		Node<T>* left = head;
		Node<T>* right = getLastNode(head);
		while (left != right) {
			Node<T>* middle = obtainMiddleNode(left, right);

			if (attribute == "rent") {
				if (middle->getData().getRent() < value.getRent())
					left = middle->next;
				else if (middle->getData().getRent() > value.getRent())
					right = middle;
				else {
					result.pushBack(middle->getData());
					break;
				}
			}
			else if (attribute == "location") {
				if (middle->getData().getLocation() < value.getLocation())
					left = middle->next;
				else if (middle->getData().getLocation() > value.getLocation())
					right = middle;
				else {
					result.pushBack(middle->getData());
					break;
				}
			}
			else if (attribute == "size") {
				if (middle->getData().getSize() < value.getSize())
					left = middle->next;
				else if (middle->getData().getSize() > value.getSize())
					right = middle;
				else {
					result.pushBack(middle->getData());
					break;
				}
			}
			else if (attribute == "id") {
				if (middle->getData().getID() < value.getID())
					left = middle->next;
				else if (middle->getData().getID() > value.getID())
					right = middle;
				else if (middle->getData().getID() == value.getID()) {
					result.pushBack(middle->getData());
					break;
				}
			}
		}
		return result;
	}
};

// Queue class (for Property)
template <typename T>
class Queue {
private:
	Node<T>* head = nullptr;
	Node<T>* tail = nullptr;
public:
	// Constructor
	Queue() {
		head = nullptr;
		tail = nullptr;
	}

	// Destructor
	~Queue() {
		Node<T>* temp = head;
		while (temp != nullptr) {
			Node<T>* nextNode = temp->next;
			// Delete temp
			temp = nextNode;
		}
		head = nullptr;
		tail = nullptr;
	}

	// Get first node
	Node<T>* getHead() {
		return head;
	}

	// Get last node
	Node<T>* getTail() {
		return tail;
	}

	Node<T>*& getHeadReference() {
		return head;
	}

	// Check if queue is empty
	bool queueEmpty() {
		return head == nullptr;
	}

	// Push a new node into the queue
	void push(T data) {
		Node<T>* newNode = new Node<T>(data);
		if (queueEmpty()) {
			head = newNode;
			tail = newNode;
		}
		else {
			tail->setNext(newNode);
			tail = newNode;
		}
	}

	// Pop a node from queue
	Node<T>* pop() {
		if (queueEmpty()) {
			throw out_of_range("Error! No data in queue!");
		}
		else {
			Node<T>* result = head;
			head = head->next;
			return result;
		}
	}
};

// Set class (for Property)
template <typename T>
class Set {
private:
	Node<T>* head = nullptr;
	Node<T>* tail = nullptr;
public:
	// Constructor
	Set() {
		head = nullptr;
		tail = nullptr;
	}

	// Destructor
	~Set() {
		Node<T>* temp = head;
		while (temp != nullptr) {
			Node<T>* nextNode = temp->next;
			// Delete temp
			temp = nextNode;
		}
		head = nullptr;
		tail = nullptr;
	}

	// Get first node
	Node<T>* getHead() {
		return head;
	}

	// Get last node
	Node<T>* getTail() {
		return tail;
	}

	// Insert a new node
	void push(T data) {
		Node<T>* newNode = new Node<T>(data);
		if (head == nullptr && tail == nullptr) {
			head = tail = newNode;
		}
		else {
			if (tail->getData() == data) {
				return;
			}
			tail->setNext(newNode);
			tail = newNode;
		}
	}

	// Check whether node is in the set
	bool contain(T data) {
		Node<T>* temp = head;
		while (temp != nullptr) {
			if (temp->getData() == data) {
				return true;
			}
			temp = temp->next;
		}
		return false;
	}

	// Delete a node from the set
	bool remove(T data) {
		Node<T>* temp = head;

		if (temp->getData() == data) {
			head = temp->next;
			return true;
		}

		if (tail->getData() == data) {
			Node<T>* currentNode = head;
			while (currentNode->next->next != nullptr) {
				currentNode = currentNode->next;
			}
			Node<T>* del = currentNode->next;
			currentNode->next = nullptr;
			tail = currentNode;
			delete del;

			return true;
		}

		while (temp->next != nullptr && !(temp->next->getData() == data)) {
			temp = temp->next;
		}

		if (temp->next == nullptr && !(temp->getData() == data)) {
			throw out_of_range("Error! Data not exist!");
			return false;
		}

		Node<T>* del = temp->next;
		temp->next = temp->next->next;
		delete del;

		return true;
	}

	// Print content
	void print() const {
		Node<T>* temp = head;
		if (temp) {
			cout << temp->getData();  // Print the first item without comma
			temp = temp->next;
		}
		while (temp != nullptr) {
			cout << ", " << temp->getData();  // Print subsequent items with a comma prefix
			temp = temp->next;
		}
	}

	void displayAll() {
		Node<T>* temp = head;
		if (temp == nullptr) {
			cout << endl;
		}
		while (temp != nullptr) {
			if (temp->next == nullptr) {
				cout << temp->getData() << endl;
				return;
			}
			cout << temp->getData() << ", ";
			temp = temp->next;
		}
	}
};

// Property class
class Property {
private:
	long id;
	string name;
	int year;
	double rent;
	string location;
	string type;
	int rooms;
	int parking;
	int bathroom;
	int size;
	string furnished;
	string region;
	List<Tenant> tenantHistoryID;
	Queue<Tenant> tenantRequest;
public:
	Set<string> facilities;
	Set<string> additionalFacilities;
	// Constructors
	Property() :
		bathroom(0), id(0), parking(0), rent(0.0), rooms(0), size(0), year(0)
	{}

	Property(long id, string name, int year, double rent, string location, string type, int rooms, int parking, int bathroom, int size, string furnished, Set<string>facilities, Set<string>additionalFacilities, string region) {
		this->id = id;
		this->name = name;
		this->year = year;
		this->rent = rent;
		this->location = location;
		this->type = type;
		this->rooms = rooms;
		this->parking = parking;
		this->bathroom = bathroom;
		this->size = size;
		this->furnished = furnished;
		this->facilities = facilities;
		this->additionalFacilities = additionalFacilities;
		this->region = region;
	}

	Property(long id, double rent, string location, int size) {
		this->id = id;
		this->rent = rent;
		this->location = location;
		this->size = size;
	}

	// Destructor
	~Property() {}

	bool operator==(const Property& other) const {
		return this->id == other.id;
	}

	long getID() const {
		return this->id;
	}

	string getName() const {
		return this->name;
	}

	int getYear() const {
		return this->year;
	}

	double getRent() const {
		return this->rent;
	}

	string getLocation() const {
		return this->location;
	}

	string getType() const {
		return this->type;
	}

	int getRooms() const {
		return this->rooms;
	}

	int getParking() const {
		return this->parking;
	}

	int getBathroom() const {
		return this->bathroom;
	}

	int getSize() const {
		return this->size;
	}

	string getFurnished() const {
		return this->furnished;
	}

	Set<string> getFacilities() const {
		return this->facilities;
	}

	Set<string> getAdditionalFacilities() const {
		return this->additionalFacilities;
	}

	string getRegion() const {
		return this->region;
	}

	// IMPORTANT : DISPLAY THE PROPERTY BASED ON RENT, LOCATION, AND SIZE THAT SORTED
	void display() {
		cout << "\n" << string(150, '=') << endl;
		cout << "\t\tID: " << this->id << "\t\t Name: " << ((this->name).length() == 0 ? "< NO NAME >" : this->name) << endl;
		cout << string(150, '=') << endl;
		cout << "Monthly Rent\t\t\t: \t\tRM " << this->rent << " per month" << endl;
		cout << "Location\t\t\t: \t\t" << this->location << endl;
		cout << "Size \t\t\t\t: \t\t" << this->size << " sq.ft." << endl;
		cout << string(150, '=') << endl;
	}
};

// *********************************************************************************************************************
// ****************************************************READ .CSV FILE***************************************************
// *********************************************************************************************************************
inline string removeSpace(const string& str) {
	size_t first = str.find_first_not_of(' ');		// Find first character that's not a space
	if (string::npos == first) { 					// If entire string consists of spaces, return the string
		return str;
	}
	size_t last = str.find_last_not_of(' ');		// Find the last character that's not a space
	return str.substr(first, (last - first + 1));	// Return the substring without leading and trailing space
}

inline List<Property>* readAllProperty() {
	List<Property>* properties = new List<Property>();
	ifstream propFile("..\\Group2_TP066984_TP067079_TP067019\\mudah-apartment-kl-selangor.csv");
	if (propFile.is_open()) {
		string line;
		getline(propFile, line); // Skip the first line (Header line)
		while (getline(propFile, line)) {
			istringstream ss(line);
			string field;
			List<string> fields;

			// Push a data row's columns into a prepared linked list
			while (ss.good()) {
				// In case the next character is quote, then quote this field and ignore commas
				if (ss.peek() == '"') {
					ss.get(); // Consume quote
					getline(ss, field, '"'); // Read up to the next quote
					ss.get(); // Consume following comma
				}
				else {
					getline(ss, field, ',');
				}
				fields.pushBack(field);
			}

			// FIRST DATA: ID - convert to long
			long id = stol(fields.getHead()->getData()); // Retrieve first node to linked list "fields" then convert data to 'long' type and assign to variable 'id' (First node should be id)
			fields.remove(fields.getHead()->getData()); // Remove first node from the "fields" after stored in the 'id' variable

			// SECOND DATA: name - string
			string name = fields.getHead()->getData(); // Retrieve data to linked list "fields" then assign to variable 'name' (no convertion needed)
			fields.remove(fields.getHead()->getData()); // Remove data from the "fields" after stored in the 'name' variable

			// THIRD DATA: year - convert to int 
			int year;
			try {
				year = fields.getHead()->getData().empty() ? 0 : stoi(fields.getHead()->getData());
			}
			catch (const invalid_argument&) { // In case invalid argument error
				// Handle the error : Set to a default value
				year = 0;
			}
			fields.remove(fields.getHead()->getData());

			// FOURTH DATA: rent - convert to double
			string rentString = fields.getHead()->getData(); // Since the rent data contain numeric and string data type
			// First remove the "RM" prefix and "per month" suffix
			if (!rentString.empty() && rentString.substr(0, 3) == "RM ") {
				rentString = rentString.substr(3); // Remove "RM" prefix
			}
			if (!rentString.empty() && rentString.substr(rentString.length() - 9) == "per month") {
				rentString = rentString.substr(0, rentString.length() - 9); // Remove "per month" suffix
			}
			rentString.erase(remove(rentString.begin(), rentString.end(), ' '), rentString.end()); // Remove all whitespace
			// Convert to double
			double rent;
			try {
				rent = stod(rentString);
			}
			catch (const invalid_argument&) { // In case invalid argument error
				rent = 0;
			}
			fields.remove(fields.getHead()->getData());

			// FIFTH DATA: location - string
			string location = fields.getHead()->getData();
			fields.remove(fields.getHead()->getData());

			// SIXTH DATA: type - string
			string type = fields.getHead()->getData();
			fields.remove(fields.getHead()->getData());

			// SEVENTH DATA: rooms - convert to int
			int rooms;
			try {
				rooms = stoi(fields.getHead()->getData());
			}
			catch (const invalid_argument&) {
				rooms = 0;
			}
			fields.remove(fields.getHead()->getData());

			// EIGHTH DATA: parking - convert to int
			int parking;
			try {
				parking = fields.getHead()->getData().empty() ? 0 : stoi(fields.getHead()->getData());
			}
			catch (const invalid_argument&) {
				parking = 0;
			}
			fields.remove(fields.getHead()->getData());

			//NINTH DATA: bathroom - convert to int
			int bathroom;
			try {
				bathroom = stoi(fields.getHead()->getData());
			}
			catch (const invalid_argument&) {
				bathroom = 0;
			}
			fields.remove(fields.getHead()->getData());

			// TENTH DATA: size - convert to int
			int size;
			try {
				size = stoi(fields.getHead()->getData());
			}
			catch (const invalid_argument&) {
				size = 0;
			}
			fields.remove(fields.getHead()->getData());

			// ELEVENTH DATA: furnished - string
			string furnished = fields.getHead()->getData();
			fields.remove(fields.getHead()->getData());

			// TWELVETH DATA: facilities - set<string>
			Set<string> facilities;
			string facData = fields.getHead()->getData();
			if (!facData.empty() && facData[0] == ',') {
				facData = facData.substr(1); // Remove leading comma
			}
			istringstream facSet(facData);
			string fac;
			while (getline(facSet, fac, ',')) {
				fac = removeSpace(fac);
				if (!fac.empty()) {
					facilities.push(fac);
				}
			}
			fields.remove(fields.getHead()->getData());

			// THIRTHEENTH DATA: additional facilities - set<string>
			Set<string> additionalFacilities;
			string addFacData = fields.getHead()->getData();
			if (!addFacData.empty() && addFacData[0] == ',') {
				addFacData = addFacData.substr(1);
			}
			istringstream addFacSet(addFacData);
			string addFac;
			while (getline(addFacSet, addFac, ',')) {
				addFac = removeSpace(addFac);
				if (!addFac.empty()) {
					additionalFacilities.push(addFac);
				}
			}
			fields.remove(fields.getHead()->getData());

			// FOURTHEENTH DATA: region - string
			string region = fields.getHead()->getData();
			fields.remove(fields.getHead()->getData());

			Property p(id, name, year, rent, location, type, rooms, parking, bathroom, size, furnished, facilities, additionalFacilities, region);
			properties->pushBack(p);
		}
		propFile.close(); // close the file after used
	}
	else {
		cout << "Error! No file found!" << endl;
		delete properties; // Free up the memory allocated
		return nullptr;
	}
	return properties;
}

inline List<Property>* copyList(List<Property>* originalList) {
	if (originalList == nullptr) {
		return nullptr;
	}
	List<Property>* newPropertiesList = new List<Property>();
	Node<Property>* currentNode = originalList->getHead();
	while (currentNode != nullptr) {
		Property copiedProperty = currentNode->getData();
		newPropertiesList->pushBack(copiedProperty);
		currentNode = currentNode->next;
	}
	return newPropertiesList;
}

// *********************************************************************************************************************
// **********************************************SAVE PROPERTY FUNCTION*************************************************
// *********************************************************************************************************************
inline bool checkRecord(string un, long pid) {
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");
	string username, propertyID = "0", request, empty;
	bool exist = false;
	while (!file.eof()) {
		getline(file, username);
		getline(file, propertyID);
		getline(file, request);
		getline(file, empty);
		username.erase(username.find_last_not_of("\r") + 1);
		propertyID.erase(propertyID.find_last_not_of("\r") + 1);
		if (username == un && propertyID == to_string(pid)) {
			exist = true;
		}
	}
	file.close();
	return exist;
}

inline void saveProperty(string username, long propertyId) {
	bool value = checkRecord(username, propertyId);
	if (value) {
		cout << "\n\t\t\tYou have saved this property before!\n" << endl;
	}
	else {
		ofstream file("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt", ios::in | ios::out | ios::app);
		file << username << endl;
		file << propertyId << endl;
		file << "false" << endl;
		file << endl;
		cout << "\n\t\t\tSaved to favourites!\n" << endl;
	}
	return;
}

// *********************************************************************************************************************
// **************************************************TENANT FUNCTION****************************************************
// *********************************************************************************************************************
// Display all tenant property information
void displayPropertyNode(List<Property>* property) {
	if (!property || !property->getHead()) {
		cout << "Error! No property found!" << endl;
		return;
	}
	system("cls");
	int displayNumber;
	char input;
	while (true) {
		cout << "Please enter how many property that you want to display: ";
		cin >> displayNumber;

		// If the input was invalid such as character input detected
		if (cin.fail()) {
			cin.clear(); // Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			cout << endl;
			cout << "Invalid input! Please enter a number!" << endl << endl;
			continue;
		}
		else if (displayNumber < 0 || displayNumber > 19991) {
			cin.clear(); // Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			cout << endl;
			cout << "Invalid number! Please try another value!" << endl << endl;
			continue;
		}
		else {
			displayProgressBar();
			system("cls");
			cout << string(150, '*') << endl;
			cout << "Displaying all tenant's property information..." << endl;
			cout << string(150, '*') << endl << endl;

			// Iterate through list and display each property
			Node<Property>* currentNode = property->getHead();
			int count = 0;	// Counter to keep track of the number of displayed properties
			const int maxDisplay = displayNumber;	// Maximum number of properties to display
			while (currentNode != nullptr && count < maxDisplay) { // Will stop loop after n properties
				Property property = currentNode->getData();

				cout << "\n" << string(150, '=') << endl;
				cout << "\t\tID: " << property.getID() << "\t\t Name: " << ((property.getName()).length() == 0 ? "< NO NAME >" : property.getName()) << endl;
				cout << string(150, '=') << endl;
				cout << "Completion Year\t\t\t: \t\t" << property.getYear() << endl;
				cout << "Monthly Rent\t\t\t: \t\tRM " << property.getRent() << " per month" << endl;
				cout << "Location\t\t\t: \t\t" << property.getLocation() << endl;
				cout << "Property Type\t\t\t: \t\t" << property.getType() << endl;
				cout << "Number of Rooms\t\t\t: \t\t" << property.getRooms() << endl;
				cout << "Number of Parking\t\t: \t\t" << property.getParking() << endl;
				cout << "Number of Bathroom\t\t: \t\t" << property.getBathroom() << endl;
				cout << "Size \t\t\t\t: \t\t" << property.getSize() << " sq.ft." << endl;
				cout << "Furnished\t\t\t: \t\t" << property.getFurnished() << endl;
				cout << "Facilities\t\t\t: \t\t";
				Set<string> facilities = property.getFacilities();
				facilities.print();
				cout << endl;
				cout << "Additional Facilities\t\t: \t\t";
				Set<string> additionalFacilities = property.getAdditionalFacilities();
				additionalFacilities.print();
				cout << endl;
				cout << "Region\t\t\t\t: \t\t" << property.getRegion() << endl << endl;
				cout << string(150, '=') << endl << endl;

				currentNode = currentNode->next;
				count++;	// Increment counter
			}
			cout << string(150, '*') << endl;
			cout << "First " << maxDisplay << " properties have been printed out!" << endl;
			cout << string(150, '*') << endl;
			cout << endl << "Press any key back to main menu...: ";
			cin >> input;
			displayProgressBar();
			tenantMainMenu();
			break;
		}
	}
}

inline void sortAndDisplayProperties(List<Property>* allProperties) {
	List<Property>* copyPropertyList = allProperties;
	system("cls");
	int userChoice;
	cout << "*********************************************************************************************************************" << endl;
	cout << "* \t\t\t\t\tWELCOME TO DISPLAY PROPERTY PAGE!\t\t\t\t\t    *" << endl;
	cout << "*********************************************************************************************************************" << endl;

	while (true) {
		cout << endl << "Please select which attribute you want to sort in descending order!" << endl;
		cout << "1. Properties' Monthly Rent" << endl;
		cout << "2. Properties' Location" << endl;
		cout << "3. Properties' Size" << endl;
		cout << "4. All in One" << endl;
		cout << "Please enter your choice: ";
		cin >> userChoice;

		// If the input was invalid such as character input detected
		if (cin.fail()) {
			cin.clear(); // Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			cout << endl;
			cout << "Invalid input! Please enter a number!" << endl << endl;
			continue;
		}
		else {
			if (userChoice == 1) {
				chrono::steady_clock::time_point startQuick = chrono::steady_clock::now();
				allProperties->quickSort("descending", "rent");
				chrono::steady_clock::time_point endQuick = chrono::steady_clock::now();
				cout << "Quick Sort time is " << chrono::duration_cast<chrono::seconds>(endQuick - startQuick).count() << " seconds" << endl;
				allProperties->display(3);
				break;
			}
			else if (userChoice == 2) {
				chrono::steady_clock::time_point startQuick = chrono::steady_clock::now();
				allProperties->quickSort("descending", "location");
				chrono::steady_clock::time_point endQuick = chrono::steady_clock::now();
				cout << "Quick Sort time is " << chrono::duration_cast<chrono::seconds>(endQuick - startQuick).count() << " seconds" << endl;
				allProperties->display(3);
				break;
			}
			else if (userChoice == 3) {
				chrono::steady_clock::time_point startQuick = chrono::steady_clock::now();
				allProperties->quickSort("descending", "size");
				chrono::steady_clock::time_point endQuick = chrono::steady_clock::now();
				cout << "Quick Sort time is " << chrono::duration_cast<chrono::seconds>(endQuick - startQuick).count() << " seconds" << endl;
				allProperties->display(3);
				break;
			}
			else if (userChoice == 4) {
				chrono::steady_clock::time_point startQuick = chrono::steady_clock::now();
				allProperties->MultiAttQuickSort("descending");
				chrono::steady_clock::time_point endQuick = chrono::steady_clock::now();
				cout << "Quick Sort time is " << chrono::duration_cast<chrono::seconds>(endQuick - startQuick).count() << " seconds" << endl;
				chrono::steady_clock::time_point startMerge = chrono::steady_clock::now();
				copyPropertyList->mergeSort(copyPropertyList->getHeadReference(), "descending");
				chrono::steady_clock::time_point endMerge = chrono::steady_clock::now();
				cout << "Merge Sort time is " << chrono::duration_cast<chrono::seconds>(endMerge - startMerge).count() << " seconds" << endl;
				allProperties->display(3);
				break;
			}
			else {
				cout << "Invalid input! Please try again!" << endl << endl;
				continue;
			}
		}
	}
}

User* loginTenant = nullptr;
inline void getRentHistory(Property p) {
	List<string> tenantHistory;
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");
	string tenantUsername, propertyID, tenantRequest, empty;
	while (getline(file, tenantUsername)) {
		getline(file, propertyID);
		getline(file, tenantRequest);
		getline(file, empty);
		tenantUsername.erase(tenantUsername.find_last_not_of("\r") + 1);
		propertyID.erase(propertyID.find_last_not_of("\r") + 1);
		tenantRequest.erase(tenantRequest.find_last_not_of("\r") + 1);
		empty.erase(empty.find_last_not_of("\r") + 1);
		if (p.getID() == stol(propertyID) && tenantRequest == "true") {
			tenantHistory.pushBack(tenantUsername);
		}
	}
	file.close();

	if (tenantHistory.size() == 0) {
		cout << "No tenant rent this property before!" << endl;
	}
	else {
		Node<string>* temp = tenantHistory.getHead();
		while (temp->next != nullptr) {
			cout << temp->getData() << ", ";
			temp = temp->next;
		}
		if (temp->next == nullptr) {
			cout << temp->getData() << "\n";
		}
	}
}

inline void displayPropertyDetails(Property p) {
	string un = getCurrentUsername();
	char input;
	cout << "Property ID: " << p.getID() << endl;
	cout << "Property Name: " << p.getName() << endl;
	cout << "Completion Year: " << p.getYear() << endl;
	cout << "Rent: RM" << p.getRent() << " per month" << endl;
	cout << "Location:  " << p.getLocation() << endl;
	cout << "Property type: " << p.getType() << endl;
	cout << "Number of rooms: " << p.getRooms() << endl;
	cout << "Number of parkings: " << p.getParking() << endl;
	cout << "Number of bathrooms: " << p.getBathroom() << endl;
	cout << "Property size: " << p.getSize() << " sq.ft." << endl;
	cout << "Furnished status: " << p.getFurnished() << endl;
	cout << "Facilities: ";
	p.facilities.displayAll();
	cout << "Additional Facilities: ";
	p.additionalFacilities.displayAll();
	cout << "Region: " << p.getRegion() << endl;
	cout << "Renting history (username): ";
	getRentHistory(p);
	cout << "Enter 's' to save the property, OR enter any key to continue: ";
	cin >> input;
	if (input == 's') {
		saveProperty(un, p.getID());
		this_thread::sleep_for(chrono::milliseconds(3000));
	}
}

inline void searchAndDisplayProperty(List<Property>& sortedProperties) {
	while (true) {
		string input;
		long id;
		char a;
		system("cls");
		cout << "*********************************************************************************************************************" << endl;
		cout << "* \t\t\t\t\tWELCOME TO SEARCH PROPERTY PAGE!\t\t\t\t\t    *" << endl;
		cout << "*********************************************************************************************************************" << endl;
		cout << "Enter the Property ID that you want to search [PRESS ANY CHARACTER KEY TO BACK MAIN MENU]: ";
		cin.ignore();
		getline(cin, input);
		try {
			id = stol(input);
		}
		catch (const exception&) {
			tenantMainMenu();
			break;
		}
		Property* s = new Property(id, 0, "test", 0);
		// Time for LINEAR SEARCH
		chrono::steady_clock::time_point startLinear = chrono::high_resolution_clock::now();
		List<Property> linearSearch = sortedProperties.linearSearch(*s, "id");
		chrono::steady_clock::time_point endLinear = chrono::high_resolution_clock::now();
		cout << "Linear search took " << chrono::duration_cast<chrono::microseconds>(endLinear - startLinear).count() << " microseconds to finish!" << endl;
		// Time for BINARY SEARCH
		sortedProperties.quickSort("ascending", "id");
		chrono::steady_clock::time_point startBinary = chrono::high_resolution_clock::now();
		List<Property> binarySearchRecord = sortedProperties.binarySearch(*s, "id");
		chrono::steady_clock::time_point endBinary = chrono::high_resolution_clock::now();
		cout << "Binary search took " << chrono::duration_cast<chrono::microseconds>(endBinary - startBinary).count() << " microseconds to finish!" << endl;
		cout << endl;
		if (linearSearch.getHead() == nullptr || binarySearchRecord.getHead() == nullptr) {
			cout << string(150, '*') << endl;
			cout << "\t\t\tProperty not exist!!\t\t\t" << endl;
			cout << string(150, '*') << endl << endl;
			cout << "Please press ANY KEY to continue search: ";
			cin >> a;
		}
		else {
			displayPropertyDetails(binarySearchRecord.getHead()->getData());
		}
	}
	return;
}

inline void placeNewRentRequest(List<string> allLine, Property p) {
	string username = getCurrentUsername();
	char a;
	system("cls");
	cout << string(150, '-') << endl;
	cout << "\t\t\t\t\t\tPLACE RENT SUCCESS!\t\t\t\t\t\t\nYou have place a rent request for desired property with property ID of " << p.getID() << endl;
	cout << string(150, '-') << endl;

	string propID = to_string(p.getID());
	Node<string>* temp = allLine.getHead();
	while (temp != nullptr) {
		if (temp->getData() == username && temp->next->getData() == propID && temp->next->next->getData() == "false") {
			temp->next->next->setData("true");
			break;
		}
		temp = temp->next;
	}

	ofstream file("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");
	temp = allLine.getHead();
	while (temp != nullptr) {
		file << temp->getData() << "\n";
		temp = temp->next;
	}
	file.close();

	cout << "Press ANY KEY to main menu: ";
	cin >> a;
	cout << endl << "\t\t\tGoing back to main menu\n" << endl;
	this_thread::sleep_for(chrono::milliseconds(1500));
	tenantMainMenu();
}

inline void displayFavouriteProperties(List<Property> sortedProperties) {
	sortedProperties.quickSort("ascending", "id");
	string username = getCurrentUsername();
	List<Property> favProperty;
	List<Property> reqProperty;
	List<string> allLine;
	ifstream file("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");
	string tenantUsername, propertyID, tenantReq, empty, input;
	int i;
	while (getline(file, tenantUsername)) {
		getline(file, propertyID);
		getline(file, tenantReq);
		getline(file, empty);
		tenantUsername.erase(tenantUsername.find_last_not_of("\r") + 1);
		propertyID.erase(propertyID.find_last_not_of("\r") + 1);
		tenantReq.erase(tenantReq.find_last_not_of("\r") + 1);
		empty.erase(empty.find_last_not_of("\r") + 1);
		allLine.pushBack(tenantUsername);
		allLine.pushBack(propertyID);
		allLine.pushBack(tenantReq);
		allLine.pushBack(empty);
		if (username == tenantUsername && tenantReq == "false") {
			Property* s = new Property(stol(propertyID), 0, "", 0);
			List<Property> result = sortedProperties.binarySearch(*s, "id");	// Binary search because it's more faster than linear search
			favProperty.pushBack(result.getHead()->getData());
		}
		else if (username == tenantUsername && tenantReq == "true") {
			Property* s = new Property(stol(propertyID), 0, "", 0);
			List<Property> result = sortedProperties.binarySearch(*s, "id");
			reqProperty.pushBack(result.getHead()->getData());
		}
	}
	file.close();
	system("cls");
	cout << string(150, '-') << endl;
	cout << "   \t\t\t\t\t\t\tLIST OF REQUESTED PROPERTY RENTING HISTORY\t\t\t\t\t\t\t    " << endl;
	cout << string(150, '-') << endl << endl;
	reqProperty.displayAll();
	if (reqProperty.size() == 0) {
		cout << string(150, '-') << endl;
		cout << "\t\t\tNO REQUESTED PROPERTIES DETECTED!\t\t\t" << endl;
		cout << string(150, '-') << endl;
	}
	cout << endl;
	displayProgressBar();
	cout << endl << endl;
	cout << string(150, '-') << endl;
	cout << "   \t\t\t\t\t\t\tLIST OF FAVOURITE PROPERTY RENTING HISTORY\t\t\t\t\t\t\t    " << endl;
	cout << string(150, '-') << endl << endl;
	favProperty.displayAll();
	cin.ignore();
	if (favProperty.size() == 0) {
		cout << string(150, '-') << endl;
		cout << "\t\t\tNO FAVOURTIE PROPERTIES DETECTED!\t\t\t" << endl;
		cout << string(150, '-') << endl;
	}
	cout << endl;
	displayProgressBar();
	cout << endl << endl;
	cout << string(150, '+') << endl;
	cout << "Please choose property index for putting rent request [Press ANY CHARACTER KEY TO CONTINUE): ";
	getline(cin, input);
	try {
		i = stoi(input);
		int count = 1;
		Node<Property>* temp = favProperty.getHead();
		while (count < i) {
			temp = temp->next;
			count++;
		}
		Property p = temp->getData();
		placeNewRentRequest(allLine, p);
	}
	catch (const exception&) {
		cout << "Invalid input! Back to main menu..." << endl;
		this_thread::sleep_for(chrono::milliseconds(1500));
		tenantMainMenu();
	}
	return;
}

// Tenant main menu
inline void tenantMainMenu() {
	// Read all property data and store all property information into a list
	List<Property>* originalPropertiesInfo = readAllProperty();
	List<Property>* allPropertiesInfo = copyList(originalPropertiesInfo);
	system("cls");
	int userChoice;
	cout << "*********************************************************************************************************************" << endl;
	cout << "*   \t\t\t\t\t\tWELCOME TO TENANT MENU!\t\t\t\t\t\t    *" << endl;
	cout << "*********************************************************************************************************************" << endl;

	while (true) {
		cout << endl << "1. List All Property Information" << endl;
		cout << "2. Sort and Display Property Information" << endl;
		cout << "3. Search and Display Property Information" << endl;
		cout << "4. Display Favourite Properties Renting History and Place New Rent Request" << endl;
		cout << "0. Logout" << endl << endl;
		cout << "Please enter your choice: ";
		cin >> userChoice;

		// If the input was invalid such as character input detected
		if (cin.fail()) {
			cin.clear(); // Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			cout << endl;
			cout << "Invalid input! Please enter a number!" << endl << endl;
			continue;
		}
		else {
			if (userChoice == 1) {
				cout << endl;
				cout << "Displaying all tenant's property information..." << endl << endl;
				displayProgressBar();
				displayPropertyNode(allPropertiesInfo);
				break;
			}
			else if (userChoice == 2) {
				cout << endl;
				cout << "Sorting tenant's property..." << endl << endl;
				displayProgressBar();
				sortAndDisplayProperties(allPropertiesInfo);
				break;
			}
			else if (userChoice == 3) {
				cout << endl;
				cout << "Searching for tenant's property..." << endl << endl;
				searchAndDisplayProperty(*originalPropertiesInfo);
				break;
			}
			else if (userChoice == 4) {
				cout << endl;
				cout << "Displaying tenant's favourite property ..." << endl << endl;
				displayFavouriteProperties(*originalPropertiesInfo);
				break;
			}
			else if (userChoice == 0) {
				displayProgressBar();
				system("cls");
				cout << "You have successfully logged out!" << endl << endl;
				userPrompt();
				break;
			}
			else {
				cout << endl;
				cout << "Invalid choice! Please try again!" << endl << endl;
				cin.clear();	// Clear the input stream state
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			}
		}
	}
}

// *********************************************************************************************************************
// *********************************************************************************************************************
// *********************************************************************************************************************
//Back to Main Menu Function
inline void returnToMainMenu() {
	cout << "Do you want to return to Main Menu?" << endl;
	cout << "1. Yes" << endl;
	cout << "Enter your option: ";
	int option;
	cin >> option;
	cin.ignore();
	if (option == 1) {
		AdminMainMenu();  // Call the Main Menu function
	}
	else {
		cout << "Invalid option. Exiting..." << endl;
	}
}

//**************************Structs and Other Classes***********************************************
//Used for addNewManager() and ModifyManagerStatus() function
struct Managers {
	int id;
	string username;
	string password;
	string status;
};

// Used for FilterTenants() function
struct Tenants {
	int id;
	string username;
	string password;
	string status;
};

//Used for FilterPropertyMenu() function
class CSVParser {
public:
	CSVParser(const string& filename) : filename(filename) {}
	vector<vector<string>> parse() {
		vector<vector<string>> data;
		ifstream file(filename);
		if (!file.is_open()) {
			cerr << "Failed to open file: " << filename << endl;
			return data;
		}
		string line;
		while (getline(file, line)) {
			vector<string> row;
			istringstream ss(line);
			string cell;

			while (getline(ss, cell, ',')) {
				row.push_back(cell);
			}
			data.push_back(row);
		}
		file.close();
		return data;
	}
private:
	const string filename;
};

//*******************Linked List Creation****************************************************
// Used for ModifyManagerStatus() function
class AdminLinkedList {
private:
	struct Node {
		Managers data;
		Node* next;
		Node(const Managers& manager) : data(manager), next(nullptr) {}
	};
	Node* head;
public:
	AdminLinkedList() : head(nullptr) {}
	// Add a new manager to the linked list
	void addManager(const Managers& manager) {
		Node* newNode = new Node(manager);
		if (!head) {
			head = newNode;
		}
		else {
			Node* current = head;
			while (current->next) {
				current = current->next;
			}
			current->next = newNode;
		}
	}
	// Display all managers in the linked list
	void displayAllManagers() {
		Node* current = head;
		while (current != nullptr) {
			cout << "-------------------------------(Manager " << current->data.id << ")-----------------------------------------------" << endl;
			cout << "Manager ID: " << current->data.id << endl;
			cout << "Manager Username: " << current->data.username << endl;
			cout << "Manager Password: " << current->data.password << endl;
			cout << "Manager Status: " << current->data.status << endl;
			cout << "______________________________________________________________________________________" << endl << endl;
			current = current->next;
		}
	}
	// Modify the status of a manager based on ID
	void modifyManagerStatus(int managerId, const string& newStatus) {
		Node* current = head;
		while (current != nullptr) {
			if (current->data.id == managerId) {
				current->data.status = newStatus;
				break;
			}
			current = current->next;
		}
	}
	// Write the updated linked list back to the file
	void writeToFile(const string& filename) {
		ofstream outFile(filename);
		if (outFile.is_open()) {
			Node* current = head;
			while (current != nullptr) {
				outFile << current->data.id << endl;
				outFile << current->data.username << endl;
				outFile << current->data.password << endl;
				outFile << current->data.status << endl;
				outFile << endl;
				current = current->next;
			}
			outFile.close();
			cout << "Manager status updated and details saved to " << filename << "." << endl;
		}
		else {
			cerr << "Error: Unable to open " << filename << " for writing." << endl;
		}
	}
};

//Used for FilterTenants() function
class AdminLinkedList2 {
private:
	struct Node {
		Tenants data;
		Node* next;
		Node(const Tenants& tenant) : data(tenant), next(nullptr) {}
	};
	Node* head;
public:
	AdminLinkedList2() : head(nullptr) {}
	// Insert a new tenant at the end of the linked list
	void insert(const Tenants& tenant) {
		Node* newNode = new Node(tenant);
		if (head == nullptr) {
			head = newNode;
		}
		else {
			Node* current = head;
			while (current->next != nullptr) {
				current = current->next;
			}
			current->next = newNode;
		}
	}

	// Display all tenants in the linked list
	void displayAllTenants() {
		Node* current = head;
		while (current != nullptr) {
			cout << "-------------------------------(Tenant " << current->data.id << ")-----------------------------------------------" << endl;
			cout << "Tenant ID: " << current->data.id << endl;
			cout << "Tenant Username: " << current->data.username << endl;
			cout << "Tenant Password: " << current->data.password << endl;
			cout << "Tenant Status: " << current->data.status << endl;
			cout << "______________________________________________________________________________________" << endl << endl;
			current = current->next;
		}
	}
};

//********************Queue Creation****************************************************
//Queue for addNewManager() function
class AdminQueue {
private:
	struct Node {
		Managers data;
		Node* next;
		Node(const Managers& manager) : data(manager), next(nullptr) {}
	};
	Node* front;
	Node* rear;
public:
	AdminQueue() : front(nullptr), rear(nullptr) {}
	// Enqueue a new manager to the queue
	void enqueue(const Managers& manager) {
		Node* newNode = new Node(manager);
		if (rear == nullptr) {
			front = newNode;
			rear = newNode;
		}
		else {
			rear->next = newNode;
			rear = newNode;
		}
	}

	// Display all managers in the queue
	void displayAllManagers() {
		Node* current = front;
		while (current != nullptr) {
			cout << "-------------------------------(Manager " << current->data.id << ")-----------------------------------------------" << endl;
			cout << "Manager ID: " << current->data.id << endl;
			cout << "Manager Username: " << current->data.username << endl;
			cout << "Manager Password: " << current->data.password << endl;
			cout << "Manager Status: " << current->data.status << endl;
			cout << "______________________________________________________________________________________" << endl << endl;
			current = current->next;
		}
	}
	// Add a public member function to access the front node
	Node* getFront() {
		return front;
	}
};

//********************Set Creation************************************************************
//Used for FilterPropertiesMenu() function
class AdminSet {
private:
	struct Node {
		string data;
		Node* next;
		Node(const string& val) : data(val), next(nullptr) {}
	};
	Node* head;
public:
	AdminSet() : head(nullptr) {}
	bool contains(const string& val) {
		Node* current = head;
		while (current != nullptr) {
			if (current->data == val) {
				return true;
			}
			current = current->next;
		}
		return false;
	}
	void add(const string& val) {
		if (!contains(val)) {
			Node* newNode = new Node(val);
			newNode->next = head;
			head = newNode;
		}
	}
	void displayAsMenu() {
		int option = 1;
		Node* current = head;
		while (current != nullptr) {
			cout << option << ". " << current->data << endl;
			current = current->next;
			option++;
		}
	}
	class Iterator {
	private:
		Node* current;
	public:
		Iterator(Node* node) : current(node) {}
		bool hasNext() const {
			return current != nullptr;
		}
		Node* getNode() const {
			return current;
		}
		void next() {
			if (current) {
				current = current->next;
			}
		}
	};
	Iterator begin() {
		return Iterator(head);
	}
};

//Set for FilterPropertyMenu() function
AdminSet extractUniqueValues(const vector<vector<string>>& data, int columnNumber) {
	AdminSet uniqueValues;
	for (size_t i = 1; i < data.size(); i++) { // Start from the second row
		const vector<string>& row = data[i];
		// Skip rows with less than 14 data items
		if (row.size() == 14) {
			if (columnNumber >= 0 && columnNumber < static_cast<int>(row.size())) {
				uniqueValues.add(row[columnNumber]);
			}
		}
		else {
			continue;
		}
	}
	return uniqueValues;
}

//Set for FilterPropertyMenu() function
AdminSet filterProperties(const vector<vector<string>>& data, int columnNumber, const string& option) {
	AdminSet propNames;
	for (size_t i = 0; i < data.size(); i++) {
		const vector<string>& row = data[i];
		if (columnNumber >= 0 && columnNumber < static_cast<int>(row.size()) && row[columnNumber] == option) {
			if (row.size() >= 2) {
				propNames.add(row[1]);
			}
		}
	}
	return propNames;
}

//**********************Option 1: Add New Manager**********************************************
//Function to add a new manager and write to Manager.txt
inline void addNewManager() {
	Managers newManager;
	cout << endl;
	cout << endl;
	cout << "Enter Manager ID: ";
	cin >> newManager.id;
	cin.ignore(); // Clear newline from previous input
	cout << "Enter Manager Username: ";
	getline(cin, newManager.username);
	cout << "Enter Manager Password: ";
	getline(cin, newManager.password);
	cout << "Enter Manager Status (Active or Inactive): ";
	getline(cin, newManager.status);
	// Enqueue the new manager to the queue
	AdminQueue managerQueue;
	managerQueue.enqueue(newManager);
	// Write manager details to manager.txt
	ofstream outFile("..\\Group2_TP066984_TP067079_TP067019\\manager.txt", ios::app);
	if (outFile.is_open()) {
		outFile << endl; // New line before new manager details
		outFile << newManager.id << endl;
		outFile << newManager.username << endl;
		outFile << newManager.password << endl;
		outFile << newManager.status << endl;
		outFile.close();
		cout << "New manager added and details saved to manager.txt file." << endl;
	}
	else {
		cerr << "Error: Unable to open manager.txt for writing." << endl;
	}
}

//**********************Option 2: Modify Manager Status*******************************************************
//Function to modify manager status and update Manager.txt
//Changes Manager Status
inline void ModifyManagerStatus() {
	AdminLinkedList managerList;
	ifstream inFile("..\\Group2_TP066984_TP067079_TP067019\\manager.txt");
	if (inFile.is_open()) {
		string line;
		Managers tempManager;
		int lineCount = 0;
		while (getline(inFile, line)) {
			lineCount++;
			switch (lineCount) {
			case 1:
				tempManager.id = stoi(line);
				break;
			case 2:
				tempManager.username = line;
				break;
			case 3:
				tempManager.password = line;
				break;
			case 4:
				tempManager.status = line;
				managerList.addManager(tempManager);
				break;
			case 5:
				lineCount = 0; // Reset line count
				break;
			}
		}
		inFile.close();
	}
	else {
		cerr << "Error: Unable to open manager.txt for reading." << endl;
		return;
	}
	managerList.displayAllManagers();
	int managerId;
	string newStatus;
	cout << "Enter the ID of the manager you want to modify: ";
	cin >> managerId;
	cin.ignore(); // Clear newline from previous input
	cout << "Enter the new status (Active or Inactive): ";
	getline(cin, newStatus);
	managerList.modifyManagerStatus(managerId, newStatus);
	managerList.writeToFile("..\\Group2_TP066984_TP067079_TP067019\\manager.txt");
}

//**********************Option 3: Display Filtered Tenants*******************************************************
//Function to display tenants based on status
inline void FilterTenants() {
	int filterCriteria;
	cout << "Filter Tenant Based on Status:" << endl;
	cout << "1. Active Tenants" << endl;
	cout << "2. Inactive Tenants" << endl;
	cout << "Enter your filtering criteria: ";
	cin >> filterCriteria;
	AdminLinkedList2 tenantList;
	ifstream inFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	if (inFile.is_open()) {
		string line;
		Tenants tempTenant;
		int lineCount = 0;
		while (getline(inFile, line)) {
			lineCount++;
			if (line.empty()) {
				if (lineCount == 5) {
					lineCount = 0; // Reset line count
				}
				continue; // Skip the rest of the loop and move to the next line
			}
			switch (lineCount) {
			case 1:
				tempTenant.id = stoi(line);
				break;
			case 2:
				tempTenant.username = line;
				break;
			case 3:
				tempTenant.password = line;
				break;
			case 4:
				tempTenant.status = line;
				if ((filterCriteria == 1 && tempTenant.status == "Active") ||
					(filterCriteria == 2 && tempTenant.status == "Inactive")) {
					tenantList.insert(tempTenant);
				}
				break;
			}
		}
		inFile.close();
	}
	else {
		cerr << "Error: Unable to open tenant.txt for reading." << endl;
		return;
	}
	tenantList.displayAllTenants();
}

//**********************Option 4: Display Filtered Properties*******************************************************
//Subroutine for Display Filtered Properties
int getColumnNumber(const vector<string>& header, const string& columnName) {
	for (size_t i = 0; i < header.size(); i++) {
		if (header[i] == columnName) {
			return i;
		}
	}
	return -1; // Column not found
}
//Function to filter properties
inline void FilterPropertyMenu() {
	CSVParser parser("..\\Group2_TP066984_TP067079_TP067019\\mudah-apartment-kl-selangor.csv");
	vector<vector<string>> data = parser.parse();
	if (data.empty()) {
		cerr << "No data found in the CSV file." << endl;
		return;
	}
	const vector<string>& header = data[0];
	AdminSet criteriaSet;
	for (size_t i = 2; i < header.size() - 1; i++) {
		criteriaSet.add(header[i]);
	}
	cout << endl;
	cout << "Filter apartments by:" << endl;
	criteriaSet.displayAsMenu();
	int selectedCriteria;
	cout << endl;
	cout << "Enter the number of the chosen criteria: ";
	cin >> selectedCriteria;
	cin.ignore();
	AdminSet::Iterator criteriaIter = criteriaSet.begin();
	int currentCriteria = 1;
	while (criteriaIter.hasNext()) {
		if (currentCriteria == selectedCriteria) {
			string chosenCriteria = criteriaIter.getNode()->data;
			cout << "You selected criteria: " << chosenCriteria << endl;
			int chosenColumn = getColumnNumber(header, chosenCriteria);
			if (chosenColumn == -1) {
				cerr << "Chosen criteria not found in the CSV file." << endl;
				return;
			}
			AdminSet uniqueValues = extractUniqueValues(data, chosenColumn);
			cout << endl;
			cout << "Available options for " << chosenCriteria << ":" << endl;
			uniqueValues.displayAsMenu();
			int selectedOption;
			cout << endl;
			cout << "Enter the number of the chosen option: ";
			cin >> selectedOption;
			cin.ignore();
			AdminSet::Iterator optionIter = uniqueValues.begin();
			int currentOption = 1;
			while (optionIter.hasNext()) {
				if (currentOption == selectedOption) {
					string chosenOption = optionIter.getNode()->data;
					cout << "You selected option: " << chosenOption << endl;
					cout << endl;
					AdminSet propNames = filterProperties(data, chosenColumn, chosenOption);
					cout << "Apartments with the criteria:" << endl;
					propNames.displayAsMenu();
					cout << endl;
					break;
				}
				optionIter.next();
				currentOption++;
			}
			break;
		}
		criteriaIter.next();
		currentCriteria++;
	}
}

//**********************Option 5: Log-Out*******************************************************
//Function to Log Out of the System
inline void AdminLogOut() {
	cout << endl;
	cout << "Goodbye! Thank you for using the Klang Valley Rent System." << endl;
	exit(0); // Terminate the program
}

//***********************MAIN MENU**********************************************************************
// Admin main menu
inline void AdminMainMenu() {
	system("cls");
	int userChoice;
	cout << "*********************************************************************************************************************" << endl;
	cout << "*   \t\t\t\t\t\tWELCOME TO ADMIN MAIN MENU!\t\t\t\t\t\t    *" << endl;
	cout << "*********************************************************************************************************************" << endl;
	while (true) {
		cout << endl << "1. Add a New Manager User" << endl;
		cout << "2. Modify the Status of the Manager" << endl;
		cout << "3. Display a List of Tenants" << endl;
		cout << "4. Display a List of Properties" << endl;
		cout << "5. Logout" << endl;
		cout << "Please enter your choice: ";
		cin >> userChoice;
		// If the input was invalid such as character input detected
		if (cin.fail()) {
			cin.clear(); // Clear the input stream state
			cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			cout << endl;
			cout << "Invalid input! Please enter a number!" << endl << endl;
			continue;
		}
		else {
			if (userChoice == 1) {
				cout << endl;
				cout << "Opening Adding New Manager Page..." << endl << endl;
				displayProgressBar();
				addNewManager();
				cout << endl;
				returnToMainMenu();
				break;
			}
			else if (userChoice == 2) {
				cout << endl;
				cout << "Opening Modify Manager Status Page..." << endl << endl;
				ModifyManagerStatus();
				cout << endl;
				returnToMainMenu();
				break;
			}
			else if (userChoice == 3) {
				cout << endl;
				cout << "Opening Tenants List Page..." << endl << endl;
				FilterTenants();
				cout << endl;
				returnToMainMenu();
				break;
			}
			else if (userChoice == 4) {
				cout << endl;
				cout << "Opening Property List Page..." << endl << endl;
				FilterPropertyMenu();
				cout << endl;
				returnToMainMenu();
				break;
			}
			else if (userChoice == 5) {
				displayProgressBar();
				cout << endl;
				cout << "You have successfully logged out!" << endl << endl;
				AdminLogOut();
				break;
			}
			else {
				cout << endl;
				cout << "Invalid choice! Please try again!" << endl << endl;
				cin.clear();	// Clear the input stream state
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard remaining input
			}
		}
	}
}

// *********************************************************************************************************************
// *********************************************************************************************************************
// *********************************************************************************************************************
struct tenantR {            //rent request related
	string tenantUsername;
	string propertyID;
	string tenancyProcess;
};

void displayTenant(const list<tenantR>& tnts) {     //displays tenants rent requests
	for (const auto& tenDisp : tnts) {              //loops through each tenant
		cout << "------------------------------------(Manage Rent Request)---------------------------------------------" << endl;
		cout << "Tenant Username: " << tenDisp.tenantUsername << endl;
		cout << "PropertyID: " << tenDisp.propertyID << endl;
		cout << "Tenancy Process: " << tenDisp.tenancyProcess << endl;
		cout << "--------------------------------(Manage Rent Request)--------------------------------------" << endl;
	}
}

void loadTenants(list<tenantR>& tntsr) {        //Load the tenants rent request from txt file
	ifstream readFile("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");         //opens favourite.txt
	if (!readFile) {
		cout << "Error opening favourite.txt" << endl;
		return;
	}
	string username, propertyID, status;
	while (getline(readFile, username) && getline(readFile, propertyID) && getline(readFile, status)) {     //reads each line from file
		if (status == "true") {                                                                             //check if status is true 
			tenantR tenancyReq;
			tenancyReq.tenantUsername = username;
			tenancyReq.propertyID = propertyID;
			tenancyReq.tenancyProcess = "";
			ifstream createFile("..\\Group2_TP066984_TP067079_TP067019\\request.txt");                                                 //creates new file for tenancy process status
			if (createFile) {
				string line;
				while (getline(createFile, line)) {
					if (line == username) {                                                     // if username match, read property ID and tenancy process status
						getline(createFile, line); // Read propertyID
						getline(createFile, line); // Read tenancyProcess
						tenancyReq.tenancyProcess = line;
						break;
					}
				}
			}
			createFile.close();
			if (tenancyReq.tenancyProcess == "") {      //if empty, ask user for confirmation on request
				char confirmation;
				cout << "Do you want to confirm the tenancy process for Tenant: " << tenancyReq.tenantUsername << " with PropertyID: " << tenancyReq.propertyID << "? (yes/no): ";
				cin >> confirmation;
				if (confirmation == 'y' || confirmation == 'Y') {       //if confirmed, writes to request.txt
					tenancyReq.tenancyProcess = "Under Tenancy";
					ofstream createFile("..\\Group2_TP066984_TP067079_TP067019\\request.txt", ios::app);
					createFile << tenancyReq.tenantUsername << endl;
					createFile << tenancyReq.propertyID << endl;
					createFile << tenancyReq.tenancyProcess << endl;
					createFile << endl;
					createFile.close();
				}
			}
			tntsr.push_back(tenancyReq);
		}
	}
	readFile.close();
}

struct favProperty
{
	string tenantUsername;  //Tenant Username
	string favPropertyID;   // ID of favourite property
	bool rentRequest;       //Indicator of true and false (Rented or not rented)
};

inline void genReport(const list<favProperty>& propertiess, const string& username) {
	int rentedCount = 0;        //counter for rented properties
	int notRentedCount = 0;     //counter for not rented properties
	list<string> rentedProp;    // List created to store the IDs of rented properties
	list<string> notrentedProp;  // List created to store the IDs of Not rented properties
	for (const auto& property : propertiess) {       //goes over the list of properties
		if (property.tenantUsername == username) {   //Checks if the property belongs to the username
			if (property.rentRequest)
			{
				rentedCount++;                      //Increment for the rented
				rentedProp.push_back(property.favPropertyID);   //Adds propertyID to the rented List
			}
			else {
				notRentedCount++;                   //Increment for the not rented
				notrentedProp.push_back(property.favPropertyID); //Adds propertyID to the not rented List
			}

		}
	}   //Displays the Report
	cout << "------------------------------------(Report)---------------------------------------------" << endl;
	cout << "Tenant Username: " << username << endl;
	cout << "RentRequest: The Tenant has " << rentedCount << " rented properties and has not rented " << notRentedCount << " of the properties." << endl;
	cout << "Favourite Property IDs: ";
	for (auto it = rentedProp.begin(); it != rentedProp.end(); ++it)    //Displays the IDs of rented properties
	{
		cout << *it;
		if (next(it) != rentedProp.end() || !notrentedProp.empty()) {
			cout << ", ";
		}
	}
	for (auto it = notrentedProp.begin(); it != notrentedProp.end(); ++it) //Displays the IDs of not rented properties
	{
		cout << *it;
		if (next(it) != notrentedProp.end()) {
			cout << ", ";
		}
	}
	cout << endl;
	cout << "--------------------------------------------------------------------------------" << endl;
}

struct Tenantss {
	int tenantID;
	string tenantUname;
	string tenantPass; //password read purpose
	string tenantStatus;
	Tenantss* next;      // pointer to the next tenant in the list
};

class TenantList {   //Class for tenantList
private:
	Tenantss* head;   // pointer to the first tenant in the list

public:
	TenantList() : head(nullptr) {} //initialize the head to nullptr
	inline void addTenant(int id, const string& username, const string& password, const string& status) {    //functions to add new tenants to the list
		Tenantss* newTenant = new Tenantss;
		newTenant->tenantID = id;
		newTenant->tenantUname = username;
		newTenant->tenantPass = password;
		newTenant->tenantStatus = status;
		newTenant->next = nullptr;
		if (!head) {              // if the list empty, make the new tenant the head
			head = newTenant;
		}
		else {                   // Travereses to the end and adds new tenant
			Tenantss* current = head;
			while (current->next) {
				current = current->next;
			}
			current->next = newTenant;
		}
	}
	inline void displayTenants() {       //Displays all tenants in the list
		Tenantss* current = head;
		int tenantNumber = 1;
		while (current)
		{
			cout << "####################################(TENANT FOUND!)#############################################" << endl;
			cout << "TenantID : " << current->tenantID << endl;
			cout << "Tenant Username: " << current->tenantUname << endl;
			cout << "TenantStatus: " << current->tenantStatus << endl << endl;
			current = current->next;
			tenantNumber++;
		}
	}
	Tenantss* searchTenant(int id) {       //searches the tenants basing on ID
		Tenantss* current = head;
		while (current) {
			if (current->tenantID == id) {
				return current;
			}
			current = current->next;
		}
		return nullptr;
	}
	inline bool displayInactiveTenants() {   //displays the inactive tenants
		Tenantss* current = head;
		bool foundInactive = false;
		while (current)
		{
			if (current->tenantStatus == "Inactive") {
				foundInactive = true;
				cout << "####################################(INACTIVE TENANT FOUND!)#############################################" << endl;
				cout << "TenantID : " << current->tenantID << endl;
				cout << "Tenant Username: " << current->tenantUname << endl;
				cout << "TenantStatus: " << current->tenantStatus << endl << endl;
			}
			current = current->next;
		}
		if (!foundInactive)
		{
			cout << "There are no Inactive Tenants Found!" << endl;
		}
		return foundInactive;
	}
	inline void deleteInactiveTenants() {            //deletes all the inactive tenants in the list
		Tenantss* current = head;
		Tenantss* prev = nullptr;
		while (current)
		{
			if (current->tenantStatus == "Inactive") {
				if (!prev) {
					head = current->next;
					delete current;
					current = head;
				}
				else {
					prev->next = current->next;
					delete current;
					current = prev->next;
				}
			}
			else {
				prev = current;
				current = current->next;
			}
		}
	}
	Tenantss* getHead() const {       //Getter function to return to the head
		return head;
	}
};
inline void showTenants() {      // Displays all the tenants from Tenant.txt
	ifstream readFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	if (!readFile) {
		cout << "Error Opening The File." << endl;
		return;
	}
	TenantList tenantList;
	int id;
	string username, password, status;
	while (readFile >> id >> username >> password >> status) {     //Reads the tenants from the file and adds to the list
		tenantList.addTenant(id, username, password, status);
	}
	readFile.close();
	tenantList.displayTenants();
}
inline void processTenants() {           //processes the tenants by searching the specific tenant basing on ID
	ifstream readFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	if (!readFile) {
		cout << "Error Opening The File" << endl;
		return;
	}
	TenantList tenantList;
	int id;
	string username, password, status;
	while (readFile >> id) {            //Reads the tenants from the file and adds to the list
		getline(readFile, username);
		getline(readFile, username);
		getline(readFile, password);
		getline(readFile, status);
		tenantList.addTenant(id, username, password, status);
	}
	readFile.close();
	bool correctInput = false;                  //checks if input is correct
	while (!correctInput)                        // loops till input is correct
	{
		cout << "Enter Tenant ID to Search: ";
		cin >> id;

		if (cin.fail())  //Checks input if not an integer
		{
			cin.clear();    //checks error
			cin.ignore(numeric_limits<streamsize>::max(), '\n');    //removes wrong input
			cout << "Input is invalid, please try again with a valid Tenant ID!" << endl;
		}
		else
		{
			correctInput = true;    //If input correct, exit loop
		}
	}
	Tenantss* foundTenant = tenantList.searchTenant(id);
	if (foundTenant) {
		cout << "Tenant Found!" << endl;
		cout << "TenantID: " << foundTenant->tenantID << endl;
		cout << "Tenant Username: " << foundTenant->tenantUname << endl;
		cout << "TenantStatus: " << foundTenant->tenantStatus << endl << endl;
	}
	else {
		cout << "Tenant not found!" << endl;
	}
}
inline void pullTenantsFromFile(TenantList& tenantList) {        //loads the tenants from tenant.txt into TenantList
	ifstream readFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	if (!readFile) {
		cout << "Error Opening The File" << endl;
		return;
	}
	int id;
	string username, password, status;
	while (readFile >> id) {                                      //Reads the tenants from the file and adds to the list
		getline(readFile, username);
		getline(readFile, username);
		getline(readFile, password);
		getline(readFile, status);
		tenantList.addTenant(id, username, password, status);
	}
	readFile.close();
}
inline void saveTenantsToFile(TenantList& tenantList) {          //saves changes in TenantList to tenant.txt
	ofstream writeFile("..\\Group2_TP066984_TP067079_TP067019\\tenant.txt");
	if (!writeFile) {
		cout << "Error Opening The File to write" << endl;
		return;
	}
	Tenantss* current = tenantList.getHead();
	while (current) {                                            //Writes each tenants to the file
		writeFile << current->tenantID << endl;
		writeFile << current->tenantUname << endl;
		writeFile << current->tenantPass << endl;
		writeFile << current->tenantStatus << endl;
		writeFile << endl;
		current = current->next;

	}
	writeFile.close();
}
inline void loadFavProp(list<favProperty>& propertiess) {        //loads the properties that are saved as favourite from favourite.txt
	ifstream readFile("..\\Group2_TP066984_TP067079_TP067019\\favourite.txt");
	if (!readFile) {
		cout << "Error Opening the File" << endl;
		return;
	}
	string username, fPropID, rentReqStat;
	while (getline(readFile, username) && getline(readFile, fPropID) && getline(readFile, rentReqStat)) {      //Reads and add the favourite properties to the list
		favProperty props;
		props.tenantUsername = username;
		props.favPropertyID = fPropID;
		props.rentRequest = (rentReqStat == "true");
		propertiess.push_back(props);
	}
	readFile.close();
}
//------------------------(Manage Tenant Payment)------------------------------------------------------------------------
// Save the updated requests data back to the file
inline void saveRequestsToFile(const vector<vector<string>>& requests, const string& filename) {
	ofstream outFile(filename);
	if (!outFile.is_open()) {
		cerr << "Failed to open the file for saving." << endl;
		return;
	}
	for (const vector<string>& request : requests) {
		for (const string& field : request) {
			outFile << field << endl;
		}
		outFile << endl;
	}
	outFile.close();
}
// Find the property name based on the property ID
string findPropertyName(const vector<vector<string>>& data, const string& prop_id) {
	for (size_t i = 1; i < data.size(); i++) {
		const vector<string>& row = data[i];
		if (row[0] == prop_id) {
			return row[1];
		}
	}
	return ""; // Property not found
}
//Generates Payment Message
inline void GeneratePaymentMessage(const string& prop_name, const string& ads_id, const string& username) {
	cout << endl;
	cout << endl;
	cout << "------------Tenancy Payment Approved--------------" << endl;
	cout << "Payment status is Completed!!!" << endl;
	cout << "Apartment " << prop_name << " is rented successfully!!!" << endl;
	cout << "Apartment ID: " << ads_id << endl;
	cout << "Username: " << username << endl;
	cout << "_________________________________________" << endl;
}
//Modifies the Payment Request in request.txt file
inline void ModifyPaymentRequestStatus(const string& filename, int requestIndex, const string& newStatus) {
	vector<string> lines;
	ifstream file(filename);
	if (!file.is_open()) {
		cerr << "Failed to open file: " << filename << endl;
		return;
	}
	string line;
	while (getline(file, line)) {
		lines.push_back(line);
	}
	file.close();
	if (requestIndex >= 0 && requestIndex < lines.size() && (requestIndex + 2) < lines.size()) {
		lines[requestIndex + 2] = newStatus;
	}
	ofstream outFile(filename);
	if (!outFile.is_open()) {
		cerr << "Failed to open file for writing: " << filename << endl;
		return;
	}
	for (const string& modifiedLine : lines) {
		outFile << modifiedLine << endl;
	}
	outFile.close();
}
//Main Function for Managing Tenant Payment
inline void ManageTenantPayment(const vector<vector<string>>& data) {
	const string requestFilename = "..\\Group2_TP066984_TP067079_TP067019\\request.txt";
	ifstream requestFile(requestFilename);
	if (!requestFile.is_open()) {
		cerr << "Failed to open the request file." << endl;
		return;
	}
	vector<vector<string>> requests; // Store requests data
	string line;
	while (getline(requestFile, line)) {
		string username, prop_id, paymentStatus;
		if (line.empty()) {
			continue; // Skip empty lines
		}
		username = line;
		getline(requestFile, prop_id);
		getline(requestFile, paymentStatus);
		vector<string> request = { username, prop_id, paymentStatus };
		requests.push_back(request);
		cout << "--------------------------------(Payment Request " << requests.size() << ")----------------------------------------" << endl;
		cout << "Username: " << username << endl;
		cout << "Property ID: " << prop_id << endl;
		cout << "Payment Status: " << paymentStatus << endl;
		cout << endl;
	}
	requestFile.close();
	int chosenRequest;
	cout << "Enter the number of the payment request to modify: ";
	cin >> chosenRequest;
	if (chosenRequest >= 1 && chosenRequest <= requests.size()) {
		int changeStatusChoice;
		cout << "Change Payment Status To?" << endl;
		cout << "1. Completed" << endl;
		cout << "2. Cancelled" << endl;
		cout << "3. No Change (Remains as 'Under Tenancy')" << endl;
		cout << "Enter your choice: ";
		cin >> changeStatusChoice;
		string newStatus;
		switch (changeStatusChoice) {
		case 1:
			newStatus = "Completed/Confirmed";
			break;
		case 2:
			newStatus = "Cancelled";
			break;
		case 3:
			newStatus = "Under Tenancy";
			break;
		default:
			cout << "Invalid choice. No changes will be made to the payment status." << endl;
			return;
		}
		// Update payment status in the requests vector
		requests[chosenRequest - 1][2] = newStatus;
		// Save updated requests data back to the file
		saveRequestsToFile(requests, requestFilename);
		if (newStatus == "Completed/Confirmed") {
			string username = requests[chosenRequest - 1][0];
			string prop_id = requests[chosenRequest - 1][1];
			string prop_name = findPropertyName(data, prop_id);
			GeneratePaymentMessage(prop_name, prop_id, username);
		}
		else if (newStatus == "Cancelled" || newStatus == "Under Tenancy") {
			cout << endl;
			cout << "Payment Status change will be saved into the request.txt file" << endl;
			cout << endl;
		}
	}
	else {
		cout << "Invalid payment request number." << endl;
	}
}
//------------------------------(Main Menu)-------------------------------------------------------------------
inline void managerMainMenu() {
	TenantList tenantList;              //to store list of tenants
	pullTenantsFromFile(tenantList);    //loads data of tenants and fills it to tenantList
	list<favProperty> favProperties;    //Creates a list to save favourite properties of tenants
	list<tenantR> tntsr;              // List to store tenantR structures
	system("cls");
	int userChoice;
	cout << "*********************************************************************************************************************" << endl;
	cout << "*   \t\t\t\t\t\tWELCOME TO MANAGER MENU!\t\t\t\t\t\t   *" << endl;
	cout << "*********************************************************************************************************************" << endl;
	while (true) {
		cout << endl << "1. List All Tenants Information" << endl;
		cout << "2. Search and Display Tenant Information" << endl;
		cout << "3. Display and delete Inactive Tenants" << endl;
		cout << "4. Search and generate report of Top 10 Favourite properties based on tenant" << endl;
		cout << "5. Manage tenancy Request status" << endl;
		cout << "6. Manage Tenancy Payment" << endl;
		cout << "0. Logout" << endl;
		cout << "Please enter your choice: ";
		cin >> userChoice;

		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << endl;
			cout << "Invalid input! Please enter a number!" << endl << endl;
			continue;
		}
		else {
			switch (userChoice) {
			case 1:
				displayProgressBar();
				cout << endl;
				tenantList.displayTenants();
				break;
			case 2:
				processTenants();
				break;
			case 3:
			{
				cout << endl;
				cout << "Displaying Inactive tenants: " << endl;
				displayProgressBar();
				cout << endl;
				bool hasInactiveTenants = tenantList.displayInactiveTenants();

				if (hasInactiveTenants) {
					cout << "Do you want to delete all inactive tenants? (y/n): ";
					char choice;
					cin >> choice;
					if (choice == 'y' || choice == 'Y') {
						tenantList.deleteInactiveTenants();
						saveTenantsToFile(tenantList);
						cout << "Inactive tenants deleted successfully!" << endl;
					}
				}
				break;
			}
			case 4:
			{
				loadFavProp(favProperties);
				string username;
				cout << "Enter the username of tenant for their favourite properties: ";
				cin >> username;
				displayProgressBar();
				cout << endl;
				genReport(favProperties, username);
				break;
			}
			case 5:
			{
				displayProgressBar();
				cout << endl;
				loadTenants(tntsr);   // Load tenants from the favourite.txt file               
				displayTenant(tntsr); // Display the tenants' information
				break;
			}
			case 6:
			{
				displayProgressBar();
				cout << endl;
				CSVParser parser("mudah-apartment-kl-selangor.csv");
				vector<vector<string>> data = parser.parse();
				ManageTenantPayment(data);
				break;
			}
			case 0:
				displayProgressBar();
				system("cls");
				cout << "Successful Logout! See you Soon!" << endl;
				return;
			default:
				cout << "Invalid choice! Please try again!" << endl;
				break;
			}
		}
	}
}

int main(void)
{
	// Main execution
	userPrompt(); // Determine user role
	return 0;
}